// Injected Script - Runs in page context to intercept network requests
// Intercepts fetch and XHR to capture GraphQL balance data from Chegg

(function () {
    'use strict';

    console.log('🔌 Chegg Balance Tracker: Network interceptor active');

    // Function to send balance data to content script
    function sendBalanceData(remaining, posted, limit, renewDate) {
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📊 CHEGG BALANCE TRACKER');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📤 DISPLAY: Remaining=' + remaining + ', Posted=' + posted + ', Limit=' + limit);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        var balanceData = {
            remaining: remaining,
            posted: posted,
            limit: limit,
            renewDate: renewDate
        };

        window.dispatchEvent(new CustomEvent('CHEGG_BALANCE_DATA', {
            detail: balanceData
        }));
    }

    // Function to process GraphQL response and extract balance
    function processResponse(url, responseData) {
        try {
            if (!url || url.indexOf('gateway.chegg.com') === -1 || url.indexOf('graphql') === -1) {
                return;
            }

            var data;
            if (typeof responseData === 'string') {
                try {
                    data = JSON.parse(responseData);
                } catch (e) {
                    return;
                }
            } else {
                data = responseData;
            }

            // Check for balance data: data.balance.chat.chatStarts
            if (data && data.data && data.data.balance &&
                data.data.balance.chat && data.data.balance.chat.chatStarts) {

                var chatStarts = data.data.balance.chat.chatStarts;
                var apiBalance = chatStarts.balance;
                var limit = chatStarts.limit;
                var posted = apiBalance;
                var remaining = limit - apiBalance;

                sendBalanceData(remaining, posted, limit, chatStarts.renewDate);
            }
        } catch (e) {
            console.log('Balance parse error:', e.message);
        }
    }

    // Store original fetch
    var originalFetch = window.fetch;

    // Override fetch
    window.fetch = function () {
        var args = arguments;
        var url = '';

        try {
            if (typeof args[0] === 'string') {
                url = args[0];
            } else if (args[0] && args[0].url) {
                url = args[0].url;
            }
        } catch (e) { }

        // Call original fetch
        var fetchPromise = originalFetch.apply(this, args);

        // If this is a Chegg GraphQL request, intercept the response
        if (url && url.indexOf('gateway.chegg.com') !== -1 && url.indexOf('graphql') !== -1) {
            fetchPromise.then(function (response) {
                var cloned = response.clone();
                cloned.text().then(function (text) {
                    try {
                        var jsonData = JSON.parse(text);
                        processResponse(url, jsonData);
                    } catch (e) { }
                }).catch(function () { });
            }).catch(function () { });
        }

        return fetchPromise;
    };

    // Store original XHR methods
    var originalXHROpen = XMLHttpRequest.prototype.open;
    var originalXHRSend = XMLHttpRequest.prototype.send;

    // Override XHR open
    XMLHttpRequest.prototype.open = function (method, url) {
        this._cheggUrl = url;
        return originalXHROpen.apply(this, arguments);
    };

    // Override XHR send
    XMLHttpRequest.prototype.send = function () {
        var xhr = this;
        var url = this._cheggUrl;

        if (url && url.indexOf('gateway.chegg.com') !== -1 && url.indexOf('graphql') !== -1) {
            xhr.addEventListener('load', function () {
                try {
                    processResponse(url, xhr.responseText);
                } catch (e) { }
            });
        }

        return originalXHRSend.apply(this, arguments);
    };

    console.log('📡 Monitoring GraphQL requests to gateway.chegg.com');

    // Balance is only fetched when admin triggers checkBalance command or after posting
    // Passive interception will still capture balance from any Chegg API calls

})();
