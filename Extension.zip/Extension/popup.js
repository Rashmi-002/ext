// Configuration - Change BASE_URL here when switching environments
// For localhost: 'https://tehub.in'
// For production: 'https://tehub.in'
const CONFIG = {
    BASE_URL: 'https://tehub.in',
    get API_URL() { return `${this.BASE_URL}/admin/api.php`; }
};

document.addEventListener('DOMContentLoaded', async () => {
    // Check if already registered
    const data = await chrome.storage.local.get(['accessToken', 'profileId', 'profileName', 'instanceId']);

    // Generate Instance ID if missing (Critical for multiple profiles with same extension)
    let instanceId = data.instanceId;
    if (!instanceId) {
        instanceId = 'inst_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
        await chrome.storage.local.set({ instanceId });
    }

    if (data.accessToken && data.profileId) {
        showActiveView({ ...data, instanceId });
    } else {
        showLoginView();
    }

    // Register Button Click
    document.getElementById('btnRegister').addEventListener('click', async () => {
        const token = document.getElementById('accessToken').value.trim();
        const status = document.getElementById('loginStatus');

        if (!token) {
            status.textContent = 'Please enter a token';
            status.className = 'status error';
            return;
        }

        status.textContent = 'Verifying...';
        status.className = 'status';

        try {
            // Get Extension ID
            const extensionId = chrome.runtime.id;

            // Call API - profile type is determined by the token
            const response = await fetch(CONFIG.API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=registerWithToken&token=${encodeURIComponent(token)}&extension_id=${extensionId}&instance_id=${instanceId}`
            });

            const result = await response.json();

            if (result.success) {
                status.textContent = 'Success!';
                status.className = 'status success';

                // Save to storage
                const newData = {
                    accessToken: token,
                    profileId: result.profile_id,
                    profileName: result.profile_name,
                    instanceId: instanceId
                };

                await chrome.storage.local.set(newData);

                setTimeout(() => {
                    showActiveView(newData);
                }, 1000);
            } else {
                status.textContent = result.message || 'Verification failed';
                status.className = 'status error';
            }
        } catch (error) {
            status.textContent = 'Connection error: ' + error.message;
            status.className = 'status error';
        }
    });
});

function showLoginView() {
    document.getElementById('loginView').classList.remove('hidden');
    document.getElementById('activeView').classList.add('hidden');
}

function showActiveView(data) {
    document.getElementById('loginView').classList.add('hidden');
    document.getElementById('activeView').classList.remove('hidden');

    document.getElementById('profileName').textContent = data.profileName;
    document.getElementById('extIdDisplay').textContent = chrome.runtime.id;

    // Populate custom profile name input
    document.getElementById('customProfileName').value = data.profileName || '';

    // Add event listener for save button
    document.getElementById('btnSaveProfileName').addEventListener('click', async () => {
        const customName = document.getElementById('customProfileName').value.trim();
        const status = document.getElementById('profileNameStatus');

        if (!customName) {
            status.textContent = 'Please enter a profile name';
            status.className = 'status error';
            setTimeout(() => status.style.display = 'none', 3000);
            return;
        }

        status.textContent = 'Saving...';
        status.className = 'status';
        status.style.display = 'block';

        try {
            // Save to local storage
            await chrome.storage.local.set({
                profileName: customName,
                chromeProfileName: customName
            });

            // Update in database
            const response = await fetch(CONFIG.API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=updateProfileName&instance_id=${data.instanceId}&profile_name=${encodeURIComponent(customName)}`
            });

            const result = await response.json();

            if (result.success) {
                status.textContent = '✅ Profile name saved!';
                status.className = 'status success';
                document.getElementById('profileName').textContent = customName;
            } else {
                status.textContent = '❌ Failed to save';
                status.className = 'status error';
            }
        } catch (error) {
            status.textContent = '❌ Error: ' + error.message;
            status.className = 'status error';
        }

        setTimeout(() => status.style.display = 'none', 3000);
    });
}
