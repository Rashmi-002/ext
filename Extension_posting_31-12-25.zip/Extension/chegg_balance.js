// Chegg Balance Content Script - Runs on Chegg pages
// Injects GraphQL interceptor and handles balance data
// Integrated into Multi-Tab Controller Extension

(function () {
    'use strict';

    console.log('🎯 Multi-Tab Controller: Chegg Balance Script Loaded');

    // Inject the interceptor script into the page context
    function injectScript() {
        var script = document.createElement('script');
        script.src = chrome.runtime.getURL('chegg_injected.js');
        script.type = 'text/javascript';
        script.onload = function () {
            console.log('✅ GraphQL interceptor loaded');
        };
        script.onerror = function (e) {
            console.error('❌ Failed to load interceptor:', e);
        };
        (document.head || document.documentElement).appendChild(script);
    }

    // Listen for balance data from the injected script
    window.addEventListener('CHEGG_BALANCE_DATA', function (event) {
        var data = event.detail;

        console.log('📊 Balance received: ' + data.remaining + '/' + data.limit + ' remaining (' + data.posted + ' posted)');

        // Wait for body then show indicator
        if (document.body) {
            showBalanceIndicator(data.remaining, data.posted, data.limit, data.renewDate);
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                showBalanceIndicator(data.remaining, data.posted, data.limit, data.renewDate);
            });
        }

        // Send to background script for storage and admin API update
        chrome.runtime.sendMessage({
            type: 'CHEGG_BALANCE_UPDATE',
            data: {
                remaining: data.remaining,
                posted: data.posted,
                limit: data.limit,
                renewDate: data.renewDate,
                timestamp: new Date().toISOString(),
                url: window.location.href
            }
        }).catch(function (err) {
            console.log('Message error:', err);
        });
    });

    // Show floating balance indicator on page
    function showBalanceIndicator(remaining, posted, limit, renewDate) {
        if (!document.body) return;

        var indicator = document.getElementById('chegg-balance-indicator');

        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'chegg-balance-indicator';
            document.body.appendChild(indicator);
        }

        // Calculate percentage REMAINING (higher = good)
        var percentage = limit > 0 ? Math.round((remaining / limit) * 100) : 0;

        // Format renew date
        var renewText = '';
        if (renewDate) {
            var date = new Date(renewDate);
            renewText = 'Renews: ' + date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        }

        // Color based on remaining (lower remaining = more critical)
        var statusClass = 'cbt-status-good';
        if (percentage <= 25) {
            statusClass = 'cbt-status-critical';
        } else if (percentage <= 50) {
            statusClass = 'cbt-status-warning';
        }

        indicator.innerHTML =
            '<div class="cbt-header">' +
            '<div class="cbt-icon">📊</div>' +
            '<div class="cbt-title">Questions Remaining</div>' +
            '</div>' +
            '<div class="cbt-main">' +
            '<div class="cbt-balance ' + statusClass + '">' + remaining + '</div>' +
            '<div class="cbt-separator">/</div>' +
            '<div class="cbt-limit">' + limit + '</div>' +
            '</div>' +
            '<div class="cbt-progress-container">' +
            '<div class="cbt-progress-bar ' + statusClass + '" style="width: ' + percentage + '%"></div>' +
            '</div>' +
            '<div class="cbt-footer">' +
            '<span class="cbt-percentage">' + posted + ' posted</span>' +
            (renewText ? '<span class="cbt-renew">' + renewText + '</span>' : '') +
            '</div>';

        indicator.classList.add('cbt-pulse');
        setTimeout(function () {
            indicator.classList.remove('cbt-pulse');
        }, 1000);

        console.log('✅ Balance indicator updated: ' + remaining + '/' + limit);
    }

    // Inject immediately
    injectScript();

})();
