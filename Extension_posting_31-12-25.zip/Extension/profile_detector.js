// Content script to detect Chrome profile name
(function () {
    'use strict';

    // Function to extract profile name from Chrome's UI
    function detectProfileName() {
        try {
            // Method 1: Check if we're on chrome://settings or similar page
            if (window.location.href.includes('chrome://')) {
                return null; // Can't access chrome:// pages
            }

            // Method 2: Try to get from document title or meta tags
            // This won't work directly, but we can send a message to background

            // Send message to background script
            chrome.runtime.sendMessage({
                action: 'detectProfileName',
                url: window.location.href
            }, (response) => {
                console.log('Profile detection response:', response);
            });

        } catch (e) {
            console.error('Profile detection error:', e);
        }
    }

    // Run detection on load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', detectProfileName);
    } else {
        detectProfileName();
    }
})();
