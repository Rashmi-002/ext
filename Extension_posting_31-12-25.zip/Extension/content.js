// ========== PRESS AND HOLD DETECTION ==========
// Patterns to detect "Press and Hold" captcha/verification challenges
const PRESS_HOLD_PATTERNS = {
    selectors: [
        '[class*="press-hold"]',
        '[class*="presshold"]',
        '[class*="hold-button"]',
        '[class*="captcha-hold"]',
        '[id*="press-hold"]',
        '[id*="hold-button"]',
        '[class*="challenge"]',
        '[class*="cf-turnstile"]',
        '#challenge-running',
        '#challenge-stage',
        '[aria-label*="press"]',
        '[aria-label*="hold"]',
        '[title*="press"]',
        '[title*="hold"]'
    ],
    textPatterns: [
        /press\s*(and|&)?\s*hold/i,
        /hold\s*(to|and)?\s*verify/i,
        /hold\s*button/i,
        /click\s*(and|&)?\s*hold/i,
        /hold.*confirm/i,
        /confirm.*hold/i,
        /pressing.*button/i
    ]
};

let pressHoldDetected = false;
let lastPressHoldCheckTime = 0;

// Detect press and hold elements on the page
function detectPressAndHold() {
    // Don't check too frequently
    const now = Date.now();
    if (now - lastPressHoldCheckTime < 2000) return pressHoldDetected;
    lastPressHoldCheckTime = now;

    let detected = false;

    // Check by selectors
    for (const selector of PRESS_HOLD_PATTERNS.selectors) {
        try {
            const elements = document.querySelectorAll(selector);
            for (const el of elements) {
                if (isElementVisible(el)) {
                    detected = true;
                    console.log('🛑 Press and Hold detected via selector:', selector, el);
                    break;
                }
            }
            if (detected) break;
        } catch (e) { }
    }

    // Check by text patterns if not found
    if (!detected) {
        const allElements = document.querySelectorAll('button, div, span, a, [role="button"], p, h1, h2, h3, h4, h5, h6');
        for (const el of allElements) {
            const text = (el.textContent || el.innerText || '').trim();
            const ariaLabel = el.getAttribute('aria-label') || '';
            const title = el.getAttribute('title') || '';
            const combinedText = `${text} ${ariaLabel} ${title}`;

            for (const pattern of PRESS_HOLD_PATTERNS.textPatterns) {
                if (pattern.test(combinedText) && isElementVisible(el)) {
                    detected = true;
                    console.log('🛑 Press and Hold detected via text pattern:', pattern, combinedText.substring(0, 50));
                    break;
                }
            }
            if (detected) break;
        }
    }

    // If state changed, report to background
    if (detected !== pressHoldDetected) {
        pressHoldDetected = detected;
        reportPressHoldStatus(detected);
    }

    return detected;
}

// Check if element is visible
function isElementVisible(el) {
    if (!el) return false;
    try {
        const style = window.getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        return style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            style.opacity !== '0' &&
            rect.width > 0 &&
            rect.height > 0;
    } catch (e) {
        return false;
    }
}

// Report press and hold status to background script
function reportPressHoldStatus(detected) {
    try {
        chrome.runtime.sendMessage({
            type: 'PRESS_HOLD_STATUS',
            detected: detected,
            url: window.location.href,
            timestamp: Date.now()
        });
        console.log(`📡 Press Hold status reported: ${detected ? '🔴 DETECTED' : '🟢 CLEAR'}`);
    } catch (e) {
        console.log('Could not report press hold status:', e.message);
    }
}

// Run detection periodically
setInterval(detectPressAndHold, 3000);

// Also run on page load
if (document.readyState === 'complete') {
    setTimeout(detectPressAndHold, 1000);
} else {
    window.addEventListener('load', () => setTimeout(detectPressAndHold, 1000));
}

// Run on DOM changes (for dynamic content)
const pressHoldObserver = new MutationObserver(() => {
    setTimeout(detectPressAndHold, 500);
});
if (document.body) {
    pressHoldObserver.observe(document.body, { childList: true, subtree: true });
}

// ========== END PRESS AND HOLD DETECTION ==========

// Listen for messages from the popup and background
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.action === 'clickButton') {
        clickButton(request.selector, request.index);
        sendResponse({ success: true, clicked: true });
    } else if (request.action === 'updateStatus') {
        showStatusOverlay(request.message, request.step, request.total);
        sendResponse({ success: true });
    } else if (request.action === 'hideStatus') {
        hideStatusOverlay();
        sendResponse({ success: true });
    } else if (request.action === 'checkPressHold') {
        // Manual check request from background
        const detected = detectPressAndHold();
        sendResponse({ success: true, detected: detected });
    }
    return true;
});

// Create status overlay on page
function showStatusOverlay(message, step, total) {
    let overlay = document.getElementById('kiro-auto-run-status');

    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'kiro-auto-run-status';
        overlay.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            z-index: 999999;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 16px;
            font-weight: 600;
            min-width: 320px;
            max-width: 400px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255,255,255,0.2);
            animation: slideIn 0.3s ease-out;
        `;

        // Add animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(overlay);
    }

    const progressBar = step > 0 ? `
        <div style="margin-top: 10px; background: rgba(255,255,255,0.3); border-radius: 10px; height: 8px; overflow: hidden;">
            <div style="background: white; height: 100%; width: ${(step / total) * 100}%; transition: width 0.3s;"></div>
        </div>
        <div style="margin-top: 8px; font-size: 12px; opacity: 0.9;">Step ${step} of ${total}</div>
    ` : '';

    overlay.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="font-size: 24px;">🤖</div>
            <div style="flex: 1;">
                <div style="line-height: 1.4;">${message}</div>
                ${progressBar}
            </div>
        </div>
    `;
}

function hideStatusOverlay() {
    const overlay = document.getElementById('kiro-auto-run-status');
    if (overlay) {
        overlay.style.transition = 'opacity 0.3s';
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 300);
    }
}

function clickButton(selector, index = 0) {
    try {
        let elements;
        try {
            elements = document.querySelectorAll(selector);
        } catch (e) {
            // If selector is invalid (e.g. just text "Ask an expert"), try finding by text
            console.log('Invalid selector, trying to find by text content:', selector);
        }

        // If no elements found by selector, try finding by text content (buttons, links, spans, divs)
        if (!elements || elements.length === 0) {
            // First try standard DOM
            let allElements = Array.from(document.querySelectorAll('button, a, span, div[role="button"], input[type="submit"]'));

            // Try to find elements in shadow roots as well
            const deepElements = [];
            function walk(root) {
                if (!root) return;
                const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
                let node;
                while (node = walker.nextNode()) {
                    if (node.matches && node.matches('button, a, span, div[role="button"], input[type="submit"]')) {
                        deepElements.push(node);
                    }
                    if (node.shadowRoot) {
                        walk(node.shadowRoot);
                    }
                }
            }
            walk(document.body);

            // Combine results
            if (deepElements.length > 0) {
                allElements = [...allElements, ...deepElements];
            }

            const textMatches = allElements.filter(el =>
                el.innerText && el.innerText.toLowerCase().includes(selector.toLowerCase())
            );

            // SPECIAL HANDLING: If selector is "Ask an expert", try XPath for precise matching of the user's specific button
            // SPECIAL HANDLING: If selector is "Ask an expert", try XPath for precise matching of the user's specific button
            // Update: Broader check for any "Ask" variation
            if (selector.toLowerCase().includes('ask') || selector.toLowerCase().includes('expert')) {
                // 1. Precise XPath finding for text variations
                const xpaths = [
                    "//span[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ask an expert')]",
                    "//span[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ask expert')]",
                    "//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ask')]",
                    "//div[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ask an expert')]",
                    "//a[contains(@href, 'ask')]"
                ];

                for (let xpath of xpaths) {
                    const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    if (element) {
                        elements = [element];
                        if (element.parentElement) elements.push(element.parentElement);
                        break;
                    }
                }

                // 2. Query Selector fallback
                if (!elements || elements.length === 0) {
                    const directAsk = document.querySelector('[data-test="ask-an-expert-button"], [aria-label*="Ask"]');
                    if (directAsk) elements = [directAsk];
                }

                if (!elements || elements.length === 0 && textMatches.length > 0) {
                    elements = textMatches;
                }
            }
            // SPECIAL HANDLING: Chat Submit Arrow
            else if (selector === 'Chat Submit' || selector.includes('submit-button')) {
                // Strategy 1: Look for the exact Chegg submit button first
                let directButton = document.querySelector('button[data-test*="submit-button"][aria-label="Submit question"]');

                // Fallback to more general selectors
                if (!directButton) {
                    directButton = document.querySelector('button[aria-label="Submit question"]');
                }
                if (!directButton) {
                    directButton = document.querySelector('button[data-test*="submit-button"]');
                }
                if (!directButton) {
                    directButton = document.querySelector('button.-submit-button');
                }

                if (directButton) {
                    elements = [directButton];
                } else {
                    // Strategy 2: Find SVG arrows (common pattern for submit buttons)
                    const svgElements = Array.from(document.querySelectorAll('svg'));
                    const arrowSvgs = svgElements.filter(svg => {
                        // Check if SVG looks like an arrow (has path with arrow-like viewBox or specific shapes)
                        const viewBox = svg.getAttribute('viewBox');
                        const paths = svg.querySelectorAll('path, polygon');
                        return paths.length > 0 || (viewBox && viewBox.includes('24'));
                    });

                    // Get parent buttons of these SVGs
                    const svgParentButtons = arrowSvgs
                        .map(svg => svg.closest('button'))
                        .filter(btn => btn !== null);

                    if (svgParentButtons.length > 0) {
                        elements = svgParentButtons;
                    } else {
                        // Strategy 3: Deep search for any submit-type buttons
                        const deepButtons = [];
                        function walkCtx(root) {
                            if (!root) return;
                            const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
                            let node;
                            while (node = walker.nextNode()) {
                                if (node.tagName === 'BUTTON') {
                                    const label = node.getAttribute('aria-label') || '';
                                    const testId = node.getAttribute('data-test') || '';
                                    const type = node.getAttribute('type') || '';
                                    const className = node.className || '';

                                    if (label.toLowerCase().includes('submit') ||
                                        testId.includes('submit') ||
                                        type === 'submit' ||
                                        className.includes('submit')) {
                                        deepButtons.push(node);
                                    }
                                }
                                if (node.shadowRoot) walkCtx(node.shadowRoot);
                            }
                        }
                        walkCtx(document.body);
                        if (deepButtons.length > 0) {
                            elements = deepButtons;
                        }
                    }
                }
            }
            else if (textMatches.length > 0) {
                elements = textMatches;
            }
        }

        if (!elements || elements.length === 0) {
            console.log(`No elements found with selector or text: ${selector}`);
            return { success: false, error: 'No elements found' };
        }

        if (index >= elements.length) {
            console.log(`Index ${index} is out of bounds. Found ${elements.length} elements.`);
            return { success: false, error: 'Index out of bounds' };
        }

        const element = elements[index];

        // Scroll element into view
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });

        // Add visual feedback
        element.style.boxShadow = '0 0 10px yellow';
        setTimeout(() => {
            element.style.boxShadow = '';
        }, 1000);

        // Simulate mouse events for a natural click (React-friendly)
        const rect = element.getBoundingClientRect();
        const clientX = rect.left + (rect.width / 2);
        const clientY = rect.top + (rect.height / 2);

        const eventOptions = {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: clientX,
            clientY: clientY,
            screenX: clientX, // rudimentary approximation
            screenY: clientY
        };

        // Focus first
        element.focus();

        // Sequence
        // SEQUENCE FOR CHAT SUBMIT - Prevent page refresh
        if (selector === 'Chat Submit' || selector.includes('submit-button')) {
            // CRITICAL: Block form submission BEFORE clicking
            const parentForm = element.closest('form');
            if (parentForm) {
                const blockSubmit = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Blocked form submission');
                };
                parentForm.addEventListener('submit', blockSubmit, { capture: true });
                // Keep it blocked for 2 seconds
                setTimeout(() => parentForm.removeEventListener('submit', blockSubmit, { capture: true }), 2000);
            }

            // Block the button's default action too
            element.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('Prevented button default action');
            }, { once: true, capture: true });

            // Just trigger the React onClick handler without native click
            element.dispatchEvent(new MouseEvent('mousedown', eventOptions));
            element.dispatchEvent(new MouseEvent('mouseup', eventOptions));
            element.dispatchEvent(new MouseEvent('click', eventOptions));
        } else {
            // Normal buttons - full click sequence
            element.dispatchEvent(new MouseEvent('mousedown', eventOptions));
            element.dispatchEvent(new MouseEvent('mouseup', eventOptions));
            element.dispatchEvent(new MouseEvent('click', eventOptions));
            element.click();
        }

        console.log(`Clicked element with selector: ${selector}[${index}]`);
        return { success: true, element: selector };

    } catch (error) {
        console.error('Error clicking button:', error);
        return { success: false, error: error.message };
    }
}

// Auto-Registration Logic for Dashboard
if (window.location.href.includes('admin/register.php')) {
    console.log('Detected Dashboard Registration Page');

    // Announce presence immediately
    const announceExtension = () => {
        try {
            const extId = chrome.runtime.id;
            console.log('Announcing Extension ID:', extId);

            // Dispatch event to page
            const event = new CustomEvent('ExtensionDetected', {
                detail: {
                    id: extId,
                    version: chrome.runtime.getManifest().version
                }
            });
            window.dispatchEvent(event);

            // Also invoke the page's handler directly if possible (for reliability)
            const script = document.createElement('script');
            script.textContent = `
                if (typeof extensionId !== 'undefined') {
                    extensionId = '${extId}';
                    console.log('Extension ID injected:', extensionId);
                    if (typeof detectExtension === 'function') detectExtension();
                }
            `;
            document.head.appendChild(script);
            script.remove();
        } catch (e) {
            console.error('Error announcing extension:', e);
        }
    };

    // Run immediately and on load
    announceExtension();
    window.addEventListener('load', announceExtension);
}

// Optional: Add context menu option for selecting buttons
document.addEventListener('contextmenu', function (event) {
    // This could be enhanced to help users find the right selector
}, false);
