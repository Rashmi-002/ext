// Injected Script - Runs in page context to intercept network requests
// Intercepts fetch and XHR to capture GraphQL balance data from Chegg
// Integrated into Multi-Tab Controller Extension

(function () {
    'use strict';

    console.log('🔌 Multi-Tab Controller: Chegg Balance Interceptor Active');

    // Function to process GraphQL response and extract balance
    function processResponse(url, responseData) {
        try {
            if (!url || url.indexOf('gateway.chegg.com') === -1 || url.indexOf('graphql') === -1) {
                return;
            }

            var data;
            if (typeof responseData === 'string') {
                try {
                    data = JSON.parse(responseData);
                } catch (e) {
                    return;
                }
            } else {
                data = responseData;
            }

            // Check for balance data: data.balance.chat.chatStarts
            if (data && data.data && data.data.balance &&
                data.data.balance.chat && data.data.balance.chat.chatStarts) {

                var chatStarts = data.data.balance.chat.chatStarts;

                // API: balance = number of questions POSTED/USED
                // API: limit = total allowed
                var apiBalance = chatStarts.balance;  // This is POSTED count (e.g., 13)
                var limit = chatStarts.limit;          // Total allowed (e.g., 20)

                // CALCULATE:
                // posted = apiBalance (what API calls "balance") = 13
                // remaining = limit - apiBalance = 20 - 13 = 7
                var posted = apiBalance;
                var remaining = limit - apiBalance;

                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                console.log('📊 CHEGG BALANCE FROM GRAPHQL API');
                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                console.log('📥 FROM API: balance=' + apiBalance + ', limit=' + limit);
                console.log('📤 CALCULATED: Remaining=' + remaining + ', Posted=' + posted);
                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

                var balanceData = {
                    remaining: remaining,  // Questions REMAINING (7) - MAIN DISPLAY
                    posted: posted,        // Questions POSTED (13) - FOOTER
                    limit: limit,          // Total allowed (20)
                    renewDate: chatStarts.renewDate
                };

                // Send to content script via custom event
                window.dispatchEvent(new CustomEvent('CHEGG_BALANCE_DATA', {
                    detail: balanceData
                }));
            }
        } catch (e) {
            console.log('Balance parse error:', e.message);
        }
    }

    // Store original fetch
    var originalFetch = window.fetch;

    // Override fetch
    window.fetch = function () {
        var args = arguments;
        var url = '';

        try {
            if (typeof args[0] === 'string') {
                url = args[0];
            } else if (args[0] && args[0].url) {
                url = args[0].url;
            }
        } catch (e) { }

        // Call original fetch
        var fetchPromise = originalFetch.apply(this, args);

        // If this is a Chegg GraphQL request, intercept the response
        if (url && url.indexOf('gateway.chegg.com') !== -1 && url.indexOf('graphql') !== -1) {
            fetchPromise.then(function (response) {
                var cloned = response.clone();
                cloned.text().then(function (text) {
                    try {
                        var jsonData = JSON.parse(text);
                        processResponse(url, jsonData);
                    } catch (e) { }
                }).catch(function () { });
            }).catch(function () { });
        }

        return fetchPromise;
    };

    // Store original XHR methods
    var originalXHROpen = XMLHttpRequest.prototype.open;
    var originalXHRSend = XMLHttpRequest.prototype.send;

    // Override XHR open
    XMLHttpRequest.prototype.open = function (method, url) {
        this._cheggUrl = url;
        return originalXHROpen.apply(this, arguments);
    };

    // Override XHR send
    XMLHttpRequest.prototype.send = function () {
        var xhr = this;
        var url = this._cheggUrl;

        if (url && url.indexOf('gateway.chegg.com') !== -1 && url.indexOf('graphql') !== -1) {
            xhr.addEventListener('load', function () {
                try {
                    processResponse(url, xhr.responseText);
                } catch (e) { }
            });
        }

        return originalXHRSend.apply(this, arguments);
    };

    console.log('📡 Monitoring GraphQL requests to gateway.chegg.com');

})();
